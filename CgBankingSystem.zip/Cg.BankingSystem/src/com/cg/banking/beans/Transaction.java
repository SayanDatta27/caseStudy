package com.cg.banking.beans;

public class Transaction {
private int transactionId;
private float ammount;
private String TransactionType;
public Transaction() {}

public Transaction(float ammount, String transactionType) {
	super();
	this.ammount = ammount;
	TransactionType = transactionType;
}

public Transaction(int transactionId, float ammount, String transactionType) {
	super();
	this.transactionId = transactionId;
	this.ammount = ammount;
	TransactionType = transactionType;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public float getAmmount() {
	return ammount;
}
public void setAmmount(float ammount) {
	this.ammount = ammount;
}
public String getTransactionType() {
	return TransactionType;
}
public void setTransactionType(String transactionType) {
	TransactionType = transactionType;
}
}
