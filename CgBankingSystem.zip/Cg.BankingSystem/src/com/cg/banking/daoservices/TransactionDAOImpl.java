package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.AccountDBUtil;

public class TransactionDAOImpl implements TransactaionDAO {

	@Override
	public boolean update(Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}
@Override
	public Transaction save(long accountNo, Transaction transaction) {
		transaction.setTransactionId(AccountDBUtil.generateTRANSACTION_ID());
		AccountDBUtil.account.get(accountNo).getTransactions().put(transaction.getTransactionId(),transaction);
		return null;
	}
@Override
	public List<Transaction> findAll(long accountNo) {
		
		 return new ArrayList<Transaction>(AccountDBUtil.account.get(accountNo).getTransactions().values());
	}
@Override
	public Transaction findOne(long accountNo, int transactionId) {
		
		return AccountDBUtil.account.get(accountNo).getTransactions().get(transactionId);
	}
}