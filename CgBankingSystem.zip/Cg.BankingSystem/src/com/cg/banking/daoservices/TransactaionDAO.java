package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Transaction;
public interface TransactaionDAO {
boolean update(Transaction transaction);
Transaction save(long accountNo, Transaction transaction);
List<Transaction> findAll(long accountNo);
Transaction findOne(long accountNo, int transactionId);
}
