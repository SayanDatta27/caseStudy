package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactaionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private AccountDAO custData1 = new AccountDAOImpl();
	private TransactaionDAO tranData1= new TransactionDAOImpl();
	public final static float minBalance = 1000;

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account acc = new Account(accountType, initBalance);
		if (initBalance <= minBalance)
			throw new InvalidAccountTypeException();
		acc = custData1.save(acc);
		acc.setAccountBalance(initBalance);
		acc.setAccountType(accountType);
		acc.setAccountStatus("Active");
		tranData1.save(acc.getAccountNo(),new Transaction(initBalance, "Deposit") );
		return acc;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers = null;
		customers = getAccountDetails(accountNo);

		if (customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Your Account is Blocked");
		else
			customers.setAccountBalance(customers.getAccountBalance() + amount);
		tranData1.save(customers.getAccountNo(),new Transaction(amount, "Deposit") );
		return customers.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo, float Amount, int pinNumber) throws InsufficientBalanceException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers = null;
		customers = getAccountDetails(accountNo);
		if (customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException("Your Account is Blocked");
		else if (customers.getAccountBalance() - Amount <= minBalance)
			throw new InsufficientBalanceException("Your Balance is Low");
		else if (customers.getPinNumber() != pinNumber)
			throw new InvalidPinNumberException("Wrong Pin");
		else
			customers.setAccountBalance(customers.getAccountBalance() - Amount);
		tranData1.save(customers.getAccountNo(),new Transaction(Amount, "Withdraw") );
		return customers.getAccountBalance();
	}
	@Override
	public boolean fundTransfer(long accountNoFrom, long accountNoTo, float transferAmount, int pinNumber)
			throws InsufficientBalanceException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo = null;
		Account customerFrom = null;
		customerTo = getAccountDetails(accountNoTo);
		customerFrom = getAccountDetails(accountNoFrom);
		if (customerFrom.getAccountBalance() - transferAmount <= minBalance)
			throw new InsufficientBalanceException();
		if (customerFrom.getPinNumber() != pinNumber)
			throw new InvalidPinNumberException();

		customerFrom.setAccountBalance(
				withdrawAmount(customerFrom.getAccountNo(), transferAmount, customerFrom.getPinNumber()));
		customerTo.setAccountBalance(depositAmount(customerTo.getAccountNo(), transferAmount));
	return true;
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account customers = custData1.findOne(accountNo);
		return customers;
	}
	@Override
	public List<Account> getAllAccountdetails() throws BankingServicesDownException {
		List<Account> customers = custData1.findAll();
		return customers;
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		return null;
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account customers = custData1.findOne(accountNo);
		if (customers == null)
			throw new AccountNotFoundException();
		else if (customers.getAccountStatus().equalsIgnoreCase("Blocked"))
			throw new AccountBlockedException();
		return customers.getAccountStatus();
	}
}
