package com.cg.banking.client;
import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientBalanceException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.AccountDBUtil;
public class MainClass {
	public static void main(String[] args) {
		long accNo;
		long accNoTo,accNoFrom;
		int pinNo;
		float Amount;
		Scanner sc=new Scanner(System.in);
		BankingServices services=new BankingServicesImpl();
		Account accountDetails=null;
		Account customer1=null;
		Account customer2=null;
		try {
				customer1=services.openAccount("Savings", 3000);
			}catch(InvalidAccountTypeException| InvalidAmountException|BankingServicesDownException e) {
				e.printStackTrace();
			}
			System.out.println("Customer1 :"+customer1);
		try {
		customer2=services.openAccount("current", 5000);
		}catch(InvalidAccountTypeException| InvalidAmountException|BankingServicesDownException e) {
			e.printStackTrace();
		}
		System.out.println("Customers2 :"+customer2);
		
		System.out.println("*****DEPOSIT*****");
		System.out.println("Enter Account No ");
		accNo=sc.nextLong();
			System.out.println("Enter Deposit Amount");
		Amount=sc.nextFloat();
		try {
			System.out.println(services.depositAmount(accNo, Amount));
			System.out.println("Balance after Deposit:"+services.getAccountDetails(accNo));
		}catch(AccountNotFoundException | BankingServicesDownException |AccountBlockedException e) {
			e.printStackTrace();
		}
		
		System.out.println("****WITHDRAW****");
		System.out.println("Enter Account No ");
		accNo=sc.nextLong();
			System.out.println("Enter WithdrawAmount");
		Amount=sc.nextFloat();
		System.out.println("Enter Pin No");
		pinNo=sc.nextInt();
		try {
			System.out.println(services.withdrawAmount(accNo, Amount, pinNo));
			System.out.println("Balance after Withdraw: "+services.getAccountDetails(accNo));
		}catch(AccountBlockedException | AccountNotFoundException|BankingServicesDownException | InsufficientBalanceException | 
				InvalidPinNumberException e) {
			e.printStackTrace();
		}
			
			System.out.println("****FundTransfer****");
			System.out.println("Enter Account No from where to withdraw  ");
			accNoFrom=sc.nextLong();
			System.out.println("Enter Account No from where to deposit  ");
			accNoTo=sc.nextLong();
				System.out.println("Enter Transfer Amount");
			Amount=sc.nextFloat();
			System.out.println("Enter Pin No");
			pinNo=sc.nextInt();
			try {
				System.out.println(services.fundTransfer(accNoFrom, accNoTo, Amount, pinNo));
				System.out.println("Balance after Transfer: "+services.getAccountDetails(accNoFrom)+services.getAccountDetails(accNoTo));
			}catch(InsufficientBalanceException | AccountNotFoundException| AccountBlockedException | BankingServicesDownException|
					InvalidPinNumberException e) {
				e.printStackTrace();
		}
	}
}
