package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;

public class AccountDBUtil {
	public static HashMap<Long, Account> account=new HashMap<>();
	public static long ACCOUNT_NUMBER=900;
	public static int TRANSAC_ID = 100;
	public static long getACCOUNT_NUMBER(){
		return ++ACCOUNT_NUMBER;
	}
	public static int generateTRANSACTION_ID() {
		return ++TRANSAC_ID;
	}
}
