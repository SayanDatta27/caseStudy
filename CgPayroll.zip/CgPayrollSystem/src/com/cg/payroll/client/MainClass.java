package com.cg.payroll.client;

import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayRollDBUtil;

public class MainClass {

	public static void main(String[] args) throws AssociateDetailNotfoundException {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails(15000, "sayan", "datta", "JAVA", "SE"," 45567", 
				"syanwt@gmail.com",300000, 12000, 12000,1234, "ICICI", "ICIC00637");

	System.out.println("AssociateId: "+PayRollDBUtil.getASSOCIATE_ID_COUNTER());
		try
		{
			System.out.println("Net Annual Salary :"+services.calculateNetSalary(associateId));
			double monNetSalary=(services.calculateNetSalary(associateId))/12;
			System.out.println("MonNetSalary:"+ monNetSalary);
		}
		catch(AssociateDetailNotfoundException e)
		{
			e.printStackTrace();
		}
		
	}
}