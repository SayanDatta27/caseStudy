package com.cg.payroll.daoservices;
import java.util.List;

import com.cg.payroll.beans.AssociateClass;
public interface AssociateDAO {
AssociateClass save(AssociateClass associate);
boolean update(AssociateClass associate);
AssociateClass findOne(int associateId);
List<AssociateClass> findAll();
}
