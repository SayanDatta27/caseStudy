package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.payroll.beans.AssociateClass;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.util.PayRollDBUtil;

public class AssociateDAOImpl implements AssociateDAO{

	@Override
	public AssociateClass save(AssociateClass associate) {
		associate.setAssociateId(PayRollDBUtil.getASSOCIATE_ID_COUNTER());
		PayRollDBUtil.associates.put(associate.getAssociateId(),associate);
		return associate;
	}

	@Override
	public boolean update(AssociateClass associate) {
		
		return false;
	}

	@Override
	public AssociateClass findOne(int associateId) {
		return PayRollDBUtil.associates.get(associateId);
	
	}

	@Override
	public List<AssociateClass> findAll() {
	return new ArrayList<>(PayRollDBUtil.associates.values());
		
	}}
